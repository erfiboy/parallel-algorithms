// Include your C header files here

#include "pth_msort.h"

void mergeSortParallel (const int* values, unsigned int N, int* sorted) {
	

}